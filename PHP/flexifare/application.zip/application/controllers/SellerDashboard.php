<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SellerDashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	function __Construct(){
		parent::__Construct();
		
		$data=array();
		//$this->session->userdata['logged_in'] /****contain all values****/
		if($this->session->userdata('logged_in')){
	 		$data['session_data']=$this->session->userdata['logged_in']->seller_full_name;
		}else{
			redirect('Register');
		}
		
		$this->load->view('templates/header-seller',$data);
		
		$this->load->helper(array('form', 'url'));
		$this->load->library(array('session', 'form_validation', 'email')); 
		$this->load->database();
		
    } 
	
	public function index()
	{
		
		  
		  $this->load->view('seller-dashboard');
		  $this->load->view('templates/footer-seller');
	}
	public function AddSellerPlan()
	{
		 
		  $this->load->view('seller-add-plan');
		  $this->load->view('templates/footer-seller');
	}
	public function AddInfo()
	{
	 	$data = $_REQUEST;
		
	  	$this->load->model('SellerModel');
		$seller_m = $this->SellerModel->Add_seller($data);
		
		if($seller_m == true){
			redirect('SellerDashboard'); 
		}
	}
	
	public function logout() 
	{

		$sess_array = array('username' => '');
		$this->session->unset_userdata('logged_in', $sess_array);
		$this->session->set_flashdata("suc_msg","Successfully Logout");
		redirect('Register');
	}
	
	
	
}
