		<div class="row wrapper border-bottom white-bg page-heading">
					<div class="col-lg-10">
						<h2>Upload Plan</h2>                  
					</div>
                	<div class="col-lg-2">
                	</div>
       </div>
		<div class="wrapper wrapper-content animated fadeInRight">
					<div class="row">
						<div class="col-lg-12">
							<div class="ibox float-e-margins">
								<div class="ibox-title">
									<h5>Please use the form below to upload the your plan</h5>
									
								</div>
								<div class="ibox-content">
									<form action="<?php echo base_url(); ?>SellerDashboard/AddInfo" method="get" class="form-horizontal">
										<div class="form-group"><label class="col-sm-2 control-label">Plan Name</label>
											<div class="col-sm-10"><input type="text" class="form-control" name="seller_plan_name" id="seller_plan_name" ></div>
										</div>
										<div class="form-group"><label class="col-sm-2 control-label">Plan Summary</label>
											<div class="col-sm-10"><textarea name="plan_summary"  style="width:100%;"></textarea></div>
										</div>
										<div class="form-group"><label class="col-sm-2 control-label">Plan Image</label>
											<div class="col-sm-10"><input type="file" name="file-upload" id="file-upload" /></div>
										</div>
										
									
										<div class="form-group">
											
											<label class="col-sm-2 control-label">Plan Details</label>
											
											<div class="col-sm-10 input_fields_container"> 
												<div class="form-group col-md-12" id="data_1">
														<div class="input-group date" style="width:25%;display: inline-table;">
															<span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" class="form-control"  name="plan_date[]" value="03/04/2014">
														</div>
														<div class="input-group" style="width:25%;display: inline-table;">
															<input type="text" class="form-control" name="plan_place[]" placeholder="Add Place">
														</div>
														<div class="input-group" style="width:25%;display: inline-table;">
															<input type="text" class="form-control" name="plan_website[]"  placeholder="Add Website">
														</div>
												</div>
										   </div>
											
										</div>
											
										<div class="form-group"><label class="col-sm-2 control-label"></label>
											<div class="col-sm-10"> 
												<div class="input-group" style="width:15%;display: inline-table;">
													<input type="button" name="Add More" value="Add More" class="btn btn-sm btn-primary add_more_button"/>
												</div>
											</div>
										</div>	
										
										
										<div class="ibox-title">
											<h5>Account Details</h5>

										</div>
										<div class="form-group"><label class="col-sm-2 control-label">Paypal Address</label>
											<div class="col-sm-10"><input type="text" class="form-control" name="paypal_address" placeholder="admin@gmail.com"> <span class="help-block m-b-none">Add Payapal address.</span>
                                    		</div>
                                		</div>
										
										<div class="hr-line-dashed"></div>
										
										<div class="form-group"><label class="col-sm-2 control-label">Card Number</label>
											<div class="col-sm-10">
												<input type="number" maxlength="16" class="form-control" name="card_number" placeholder="424242424242">
                                    		</div>
                                		</div>
										<div class="form-group"><label class="col-sm-2 control-label">Card Holder Name</label>
											<div class="col-sm-10">
												<input type="text" class="form-control" name="card_holdername" placeholder="Card Holder Name">
											</div>
										</div>
										<div class="form-group"><label class="col-sm-2 control-label">Card Name</label>
											<div class="col-sm-10">
												<input type="text" class="form-control" name="card_name" placeholder="Visa">
											</div>
										</div>
										<div class="form-group"><label class="col-sm-2 control-label">Expires On</label>
											<div class="col-sm-10"> 
													<select id="selectMonth" name="selectMonth" style="width:auto;" class="form-control selectWidth">
														<?php for ($i = 1; $i <= 31; $i++){ ?>
														<option class=""><?php echo $i; ?></option>
														<?php } ?>
													</select>
													<select id="selectYear" name="selectYear" style="width:auto;" class="form-control selectWidth">
														<?php for ($i = 1980; $i <= 2050; $i++){ ?>
														<option class=""><?php echo $i; ?></option>
														<?php } ?>
													</select>
                                    		</div>
                                		</div>
										<div class="form-group"><label class="col-sm-2 control-label">Security Code / CVV</label>
											<div class="col-sm-10">
												<input type="password" class="form-control" name="card_cvv" placeholder="123">
											</div>
										</div>
										
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
										<?php $us_data = $this->session->userdata('logged_in');?>
										<input type="hidden" name="seller_id" value="<?php echo $us_data->seller_id; ?>">
                                        <button class="btn btn-white" type="submit">Cancel</button>
                                        <button class="btn btn-primary" type="submit">Save changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    