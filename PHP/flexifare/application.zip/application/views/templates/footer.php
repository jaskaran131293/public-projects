
    <div class="clearfix"></div>

    <!--FOOTER-SECTION-START-->

    <footer>
        <div class="footer-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="logo-bottom"><img src="<?php echo base_url(); ?>/assets/images/logo.png"></div>
                        <div class="footer-text">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text. </p>
                        </div>
                        <div class="footer-social-icon animated bounce">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="footer-border-line">
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 nav-padd">
                        <div class="footer-nav">
                            <ul>
                                <li class="active"><a href="#">Home</a></li>
                                <li><a href="#about">Sell your plan</a></li>
                                <li><a href="#contact">Travel plan</a></li>
                                <li><a href="#contact">Contact us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 nav-padd">
                        <div class="footer-copy-right">
                            <p><span class="seven">© 2017</span> <span class="flex-bold">Flex</span><span class="seven">Fare,</span> <span class="all">all rights reserved</span></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </footer>
    <!--FOOTER-SECTION-END-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
</body>

</html>