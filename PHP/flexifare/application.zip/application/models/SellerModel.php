<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SellerModel extends CI_Model 
{
	function __construct()
	{
		// Call the Model constructor
		parent::__construct();
		$this->load->database();
		$this->load->helper('date');
		$this->load->library('session');
	}
	
	
	Public function Add_seller($data)
	{
		
	
		$data_qu = array(
		'plan_name'=>$data['seller_plan_name'],
		'seller_id'=>$data['seller_id'],
		'plan_summary'=>$data['plan_summary'],
		'plan_image'=>$data['plan_image'],
		'plan_details'=>$data['plan_details'],
		'paypal_address'=>$data['paypal_address'],
		'card_detail'=>$data['card_detail'],
		);
		
		$usr_data = $this->db->insert('add_seller_detail',$data_qu);

		return true;
	}	
	
}

